package com.nytimes.Utils;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.nytimes.BrowserInstance.BrowserHandle;

public class PageUtil {

//	public static WebElement findBy(By webLocator) {
//
//		WebElement temp_android = (WebElement) BrowserHandle.getDriver().findElement(webLocator);
//		return temp_android;
//
//	}
//
//	public static List<WebElement> findBys(By webLocator) {	
//
//		List<WebElement> temp_android = BrowserHandle.getDriver().findElements(webLocator);
//		return temp_android;
//
//
//	}
}
